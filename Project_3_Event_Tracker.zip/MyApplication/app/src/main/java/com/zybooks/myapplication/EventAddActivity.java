package com.zybooks.myapplication;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class EventAddActivity extends AppCompatActivity {
    EditText name, detail, date;
    Button add, view;
    CheckBox allowSMS;
    DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_add);

        name = findViewById(R.id.event_name_field);
        detail = findViewById(R.id.event_detail_field);
        date = findViewById(R.id.event_date_field);
        add = findViewById(R.id.button_add);
        view = findViewById(R.id.button_view);
        allowSMS = findViewById(R.id.sms_notification_checkbox);

        DB = new DBHelper(this);

        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               startActivity(new Intent(EventAddActivity.this, EventsActivity.class));
            }
        });

        add.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                String nameStr = name.getText().toString();
                String detailStr = detail.getText().toString();
                String dateStr = date.getText().toString();

                Boolean checkAdd  = DB.insertEventData(nameStr, detailStr, dateStr);

                if(checkAdd) {
                    Toast.makeText(EventAddActivity.this, "New entry added!", Toast.LENGTH_SHORT);
                } else {
                    Toast.makeText(EventAddActivity.this, "Entry not added", Toast.LENGTH_SHORT);
                }
            }
        });
        allowSMS.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if(isChecked){
                   //todo create function to send/receive sms reminders
                }
            }
        });
    }
}
