package com.zybooks.myapplication;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class EventsActivity extends AppCompatActivity {
    FloatingActionButton fAdd;
    RecyclerView recyclerView;
    ArrayList<String> name, detail, date;
    DBHelper DB;
    MyAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_events);

        fAdd = (FloatingActionButton) findViewById(R.id.fabAdd);
        DB = new DBHelper(this);
        name = new ArrayList<>();
        detail = new ArrayList<>();
        date = new ArrayList<>();
        recyclerView = findViewById(R.id.recycler_view);
        adapter = new MyAdapter(this, name, detail, date);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        displayData();

        fAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),EventAddActivity.class);
                startActivity(intent);
            }
        });
    }

    private void displayData() {
        Cursor cursor = DB.getData();
        if(cursor.getCount()==0){
            Toast.makeText(EventsActivity.this, "No Entries Yet", Toast.LENGTH_SHORT).show();
            return;
        } else {
            while (cursor.moveToNext()) {
                name.add(cursor.getString(0));
                detail.add(cursor.getString(1));
                date.add(cursor.getString(2));
            }
        }
    }


}