package com.zybooks.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {

    EditText username, password;
    Button login, signup;
    DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        username = (EditText) findViewById(R.id.username_input);
        password = (EditText) findViewById(R.id.user_password);
        signup = (Button) findViewById(R.id.signup);
        login = (Button) findViewById(R.id.login);
        DB = new DBHelper(this);

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user = username.getText().toString();
                String pass = password.getText().toString();

                if(user.equals("") || pass.equals("")) {
                    Toast.makeText(MainActivity.this, "Fields cannot be blank", Toast.LENGTH_SHORT).show();
                } else {
                    Boolean checkuser = DB.checkUsername(user);
                    if(!checkuser) {
                        Boolean insert = DB.insertData(user, pass);
                        if(insert) {
                            Toast.makeText(MainActivity.this, "Registered " + user +"!", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(getApplicationContext(),EventsActivity.class);
                            startActivity(intent);
                        } else {
                            Toast.makeText(MainActivity.this, "Registration failed.", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(MainActivity.this, "User already exists, please sign in!", Toast.LENGTH_SHORT).show();
                    }
                }

            }
        });

        login.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                String user = username.getText().toString();
                String pass = password.getText().toString();

                if(user.equals("") || pass.equals("")) {
                    Toast.makeText(MainActivity.this, "Fields cannot be blank", Toast.LENGTH_SHORT).show();
                } else {
                    Boolean checkUserAndPass = DB.checkNameAndPassword(user, pass);
                    if(checkUserAndPass) {
                        Toast.makeText(MainActivity.this, "Login Successful!", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(getApplicationContext(), EventsActivity.class);
                        startActivity(intent);
                    } else {
                        Toast.makeText(MainActivity.this, "Wrong username/password or please sign up.", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}