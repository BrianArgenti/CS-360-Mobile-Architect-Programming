package com.zybooks.myapplication;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {
    private static final String DBNAME = "AppData.db";

    private static final String USER_TABLE = "CREATE TABLE users (username TEXT primary key, password TEXT)";
    private static final String EVENT_TABLE = "CREATE TABLE events (name TEXT primary key, detail TEXT, date TEXT)";

    public DBHelper(Context context) {
        super(context, "AppData.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(USER_TABLE);
        db.execSQL(EVENT_TABLE);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("drop table if exists users");
        db.execSQL("drop table if exists events");
        onCreate(db);
    }

    public Boolean insertData(String username, String password) {
        SQLiteDatabase userDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("username", username);
        contentValues.put("password", password);
        long result = userDB.insert("users", null, contentValues);
        return result != -1;
    }

    public Boolean insertEventData(String name, String detail, String date) {
        SQLiteDatabase eventDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("name", name);
        contentValues.put("detail", detail);
        contentValues.put("date", date);
        long result = eventDB.insert("events", null, contentValues);
        return result != -1;
    }

    public Boolean checkUsername(String username) {
        SQLiteDatabase userDB = this.getWritableDatabase();
        Cursor cursor = userDB.rawQuery("Select * from users where username = ?"
                , new String[]{username});
        return cursor.getCount() > 0;
    }

    public Boolean checkNameAndPassword(String username, String password) {
        SQLiteDatabase userDB = this.getWritableDatabase();
        Cursor cursor = userDB.rawQuery("Select * from users where username = ? and password = ?"
                , new String[]{username,password});
        return cursor.getCount() > 0;
    }

    public Cursor getData() {
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("Select * from events", null);
        return cursor;
    }
}
